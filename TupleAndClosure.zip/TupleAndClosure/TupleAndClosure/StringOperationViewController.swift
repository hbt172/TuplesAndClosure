//
//  StringOperationViewController.swift
//  TupleAndClosure
//
//  Created by Nirav Joshi on 22/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class StringOperationViewController: UIViewController {
    let dollarSign = "\u{24}"        // $,  Unicode scalar U+0024
    let blackHeart = "\u{2665}"      // ♥,  Unicode scalar U+2665
    let sparklingHeart = "\u{1F496}" // 💖, Unicode scalar U+1F496

    override func viewDidLoad() {
        super.viewDidLoad()
        print(dollarSign)
        print(blackHeart)
        print(sparklingHeart)
        
        let possibleNumber = "123"
        let convertedNumber = Int(possibleNumber)
        
        print(convertedNumber as Any)
        
        let minusSix = -6
        let alsoMinusSix = +minusSix
        print(alsoMinusSix)
        
        let three = 3
        let minusThree = -three       // minusThree equals -3
        let plusThree = -minusThree
        print("\(minusThree) \(plusThree)")

        
        let quotation = """
The White Rabbit put on his spectacles.  "Where shall I begin,please your Majesty?" he asked."Begin at the beginning," the King said gravely, "and go on till you come to the end; then stop."
"""
        
        print(quotation)
        
        
        var word = "cafe"
        print("the number of characters in \(word) is \(word.count)")
        // Prints "the number of characters in cafe is 4"
        
        word += "\u{301}"    // COMBINING ACUTE ACCENT, U+0301
        
        print("the number of characters in \(word) is \(word.count)")
        
        
        ////////
        
        let greeting = "Guten Tag!"
        print(greeting.indices)
        for index in greeting.indices {
            print("\(greeting[index]) ", terminator: "")
        }
        
        
        ////////////
        
        var welcome = "hello"
        welcome.insert("!", at: welcome.endIndex)
        // welcome now equals "hello!"
        
        welcome.insert(contentsOf: " there", at: welcome.index(before: welcome.endIndex))
        
        // hello there!
        
        print(welcome.index(welcome.endIndex, offsetBy: -6))
        
        let range = welcome.index(welcome.endIndex, offsetBy: -6)..<welcome.endIndex
        
        
        welcome.removeSubrange(range)
        
        let range1 = welcome.startIndex..<welcome.index(welcome.startIndex, offsetBy: 5)
        
        welcome.removeSubrange(range1)
        
        
        //////////////
        
        let greeting1 = "Hello, world!"
        let index = greeting1.index(of: ",")
        let begning = greeting1.prefix(upTo: index!)
        
  //      let beginning = greeting1[..<index]
    
        
        
        var shoppingList = ["Eggs", "Milk","Floar","abc","xyz","pqr","hbt"]
        shoppingList[4...6] = ["Bananas", "Apples"]
        print(shoppingList)
        
        
        var setType = Set<String>()
        
        setType.insert("a")
        
        
        //DictionaryData()
     //   WhileData()
//       SwitchCase()
        //TupleData()
//        ControlTransferStatement()
//        closureExample()
        StructureAndClass()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func  DictionaryData() {
        
        var airports = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
        
       if let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB") {
        print("The old value for DUB was \(oldValue).")
        }
        print(airports)
        
        airports["APL"] = "Apple International"
        print(airports)
        airports["APL"] = nil
        print(airports)
        
        let minuteInterval = 5
        for tickMark in stride(from: 0, to: 60, by: minuteInterval) {
            // render the tick mark every 5 minutes (0, 5, 10, 15 ... 45, 50, 55)
            print(tickMark)
        }
    }
    
    func WhileData()  {
        let finalSquare = 25
        var board = [Int](repeating: 0, count: finalSquare + 1)
        
        print(board)
        
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
        
        print(board)
        
    }
    
    func SwitchCase() {
        let approximateCount = 62
        let countedThings = "moons orbiting Saturn"
        var naturalCount : String
        
        switch approximateCount {
        case 0:
            naturalCount = "no"
        case 1..<5:
            naturalCount = "a few"
        case 5..<12:
            naturalCount = "several"
        case 12..<100:
            naturalCount = "dozens of"
        case 100..<1000:
            naturalCount = "hundreds of"
        default:
            naturalCount = "many"
        }
        print("There are \(naturalCount) \(countedThings).")
    }
    
    func TupleData()  {
        let anotherPoint = (2, 0)
        switch anotherPoint {
        case (let x, 0):
            print("on the x-axis with an x value of \(x)")
        case (0, let y):
            print("on the y-axis with a y value of \(y)")
        case let (x, y):
            print("somewhere else at (\(x), \(y))")
        }
        
    }
    
    func ControlTransferStatement()  {
        
        // continue
        
        let integerToDescribe = 5
        var description = "The number \(integerToDescribe) is"
        switch integerToDescribe {
        case 2, 3, 5, 7, 11, 13, 17, 19:
            description += " a prime number, and also"
            fallthrough
        case 20,21:
            description += "Hello"
            fallthrough
        default:
            description += " an integer."
        }
        print(description)
    }
    
    func closureExample() {
        var customersInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
        print(customersInLine.count)
        // Prints "5"
        
        let customerProvider = { customersInLine.remove(at: 0) }
        print(customersInLine.count)
        print(customerProvider())
    }
    
    func StructureAndClass() {
        struct FixedLengthRange {
            var firstValue: Int
            let length: Int
        }
        var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
        // the range represents integer values 0, 1, and 2
        print("\(rangeOfThreeItems)\(rangeOfThreeItems.firstValue)")
        rangeOfThreeItems.firstValue = 6
        print(rangeOfThreeItems.firstValue)
        
        /////////////////
        
        
        struct Point {
            var x = 0.0, y = 0.0
        }
        struct Size {
            var width = 0.0, height = 0.0
        }
        struct Rect {
            var origin = Point()
            var size = Size()
            var center: Point {
                get {
                    let centerX = origin.x + (size.width / 2)
                    let centerY = origin.y + (size.height / 2)
                    return Point(x: centerX, y: centerY)
                }
                set(newCenter) {
                    origin.x = newCenter.x - (size.width / 2)
                    origin.y = newCenter.y - (size.height / 2)
                }
            }
        }
        var square = Rect(origin: Point(x: 0.0, y: 0.0),
                          size: Size(width: 10.0, height: 10.0))
        let initialSquareCenter = square.center
        square.center = Point(x: 15.0, y: 15.0)
        print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
    }
    
    
    
}
