//
//  ClosureExampleVC.swift
//  TupleAndClosure
//
//  Created by Nirav Joshi on 21/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ClosureExampleVC: UIViewController {

    
   
    // a closure that has no parameters and return a String
    var MyName : () -> (String) = {
            return "Hardik"
    }
    
    // a closure that take one Int and return an Int
    var double: (Int) -> (Int) = { x in
        return 2 * x
    }
    
    // sort array
    var numbers = [1, 4, 2, 5, 8, 3]

    var double1: (Int,Int) -> (Int) = {
        return $0 * $1
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(MyName())
        print(double(2))
        
        
        let a = 10
        let b = 5
        
        numbers.sort(by: <) // this will sort the array in ascending order
        numbers.sort(by: >) // this will sort the array in descending order
        
        print(numbers.sort(by: <))
        print(numbers.sort(by: >))
        
        numbers.sort(by: { x , y in
            return x < y
        })
        
        
        numbers.sort { $0 < $1 }
       
        
        print(numbers)
        
        print(double1(1,2))
        
        
        let sumnumber =  sum(from: 1, to: 10, f:{
            $0
        })
        
       let sum1 = sum(from: 1, to: 10) {
            $0
        }
        
        print("\(sumnumber) \(sum1)")
        
        //////////////////////
        
        let numbers1 = [1, 2, 3]
        
        let strings = numbers1.map { "\($0)" }
        
        print(strings)
        
        
        
        ///////////////
        
        // Find the sum of the squares of all the odd numbers from numbers and then print it. Use map, filter and reduce to solve this problem.
        

        var numbers3 = [1, 2, 3, 4, 5, 6]
        
        let sum2 = numbers3.filter {
            $0 % 2 == 1 //select all the odd numbers
            }.map {
                $0 * $0 // square them
            }.reduce(0, +) // get their sum
        
        print(sum2)
        
        forEach([1, 2, 3, 4]) {
            print($0 * $0)
        }
    
        
        var array1 = [5,14,77,12]
        var array2 = [1,5,3,13]
      print(  combineArrays(array1,array2) {
            return max($0,$1)
        })
        
        
        ////
        
        
        var strings1 = ["tuples", "are", "awesome", "tuples", "are", "cool",
                       "tuples", "tuples", "tuples", "shades"]
        
        var countedStrings: [(String,Int)] = []
        
        for string in strings1 {
            var alreadyExists = false
            
            for i in 0..<countedStrings.count {
                if (countedStrings[i].0 == string) {
                    countedStrings[i].1 += 1
                    alreadyExists = true
                }
            }
            
            if alreadyExists == false {
                let tuple = (string,1)
                countedStrings.append((string,1))
            }
        }
        
        print(countedStrings)
        
        
        
        
        
        // dictionary
        
        var code = [
            "a" : "b",
            "b" : "c",
            "c" : "d",
            "d" : "e",
            "e" : "f",
            "f" : "g",
            "g" : "h",
            "h" : "i",
            "i" : "j",
            "j" : "k",
            "k" : "l",
            "l" : "m",
            "m" : "n",
            "n" : "o",
            "o" : "p",
            "p" : "q",
            "q" : "r",
            "r" : "s",
            "s" : "t",
            "t" : "u",
            "u" : "v",
            "v" : "w",
            "w" : "x",
            "x" : "y",
            "y" : "z",
            "z" : "a"
        ]
        
        var encodedMessage = "uijt nfttbhf jt ibse up sfbe"
        
        var decoder: [String:String] = [:]
        
        // reverse the code
        for (key, value) in code {
            decoder[value] = key
        }
        
        var decodedMessage = ""
        
        for char in encodedMessage.characters {
            var character = "\(char)"
            
            if let encodedChar = decoder[character] {
                // letter
                decodedMessage += encodedChar
            } else {
                // space
                decodedMessage += character
            }
        }
        
        print(decodedMessage)
        
        
        /// dictionary second example
        
        var people: [[String:Any]] = [
            [
                "firstName": "Calvin",
                "lastName": "Newton",
                "score": 13
            ],
            [
                "firstName": "Garry",
                "lastName": "Mckenzie",
                "score": 23
            ],
            [
                "firstName": "Leah",
                "lastName": "Rivera",
                "score": 10
            ],
            [
                "firstName": "Sonja",
                "lastName": "Moreno",
                "score": 3
            ],
            [
                "firstName": "Noel",
                "lastName": "Bowen",
                "score": 16
            ]
        ]
        
        func compareScores(_ first: [String:Any], second: [String:Any]) -> Bool {
            if let a = first["score"] as? Int {
                if let b = second["score"] as? Int {
                    return a > b
                }
            }
            return false
        }

       people.sort(by: compareScores(_:second:))
    
        print(people.enumerated())
        
        for (index, person) in people.enumerated() {
            if let firstName = person["firstName"] as? String {
                if let lastName = person["lastName"] as? String  {
                    if let score = person["score"] as? Int {
                        print("\(index + 1). \(firstName) \(lastName) - \(score)")
                    }
                }
            }
        }
        
        
        ///
        
        
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func forEach(_ array: [Int], _ closure: (Int) -> ()) {
        for number in array {
            closure(number)
        }
    }
    
    func sum(from: Int, to: Int, f: (Int) -> (Int)) -> Int {
        var sum = 0
        for i in from...to {
            sum += f(i)
        }
        return sum
    }
    
    func combineArrays(_ array1: [Int],
                       _ array2: [Int],
                       _ closure: (Int,Int) -> Int) -> [Int] {
        var result: [Int] = []
        for i in 0..<array1.count {
            result.append(closure(array1[i],array2[i]))
        }
        return result
    }

    
    
}
