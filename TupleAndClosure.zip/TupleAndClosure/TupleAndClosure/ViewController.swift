//
//  ViewController.swift
//  TupleAndClosure
//
//  Created by Nirav Joshi on 21/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
// tuple practice
    var person = (name: "Hardik", lName :"Talaviya",objBool:true)
    var (a,b,c) = ("hardik","Talaviya",true)
    var (x, y, z) = (1, 2, 3)

    override func viewDidLoad() {
        super.viewDidLoad()
        x=10
        y=20
       (a,b)=(b,a)
        print("\(a) \(b) \(x) \(y)")
        print(person.lName)
        print(person.objBool)
        
       let abc = divmod(10, 10)
        print("\(abc.0) , \(abc.1)")
        
        let swipeStr = swipeString(Fname: "Hardik", Lname: "Talaviya")
        print("\(swipeStr.Fname) \(swipeStr.Lname)")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func divmod(_ a: Int,_ b:Int) -> (Int, Int) {
        return (a / b, a % b)
    }

    
    func swipeString(Fname : String, Lname : String) -> (Fname : String,Lname : String) {
        return (Lname,Fname)
    }
    
}

